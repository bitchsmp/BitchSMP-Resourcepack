# BitchSMP-Resourcepack
Mandatory resourcepack for BitchSMP players

Current Version: 1.21.8
